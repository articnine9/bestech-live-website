export { default } from "./Pricing";
