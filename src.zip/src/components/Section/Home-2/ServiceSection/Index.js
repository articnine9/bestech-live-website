export { default } from "./ServiceSection";
