export { default } from "./ProductDetail";
