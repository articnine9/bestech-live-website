export { default } from "./Team";
