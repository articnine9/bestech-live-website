export { default } from "./Faq";
